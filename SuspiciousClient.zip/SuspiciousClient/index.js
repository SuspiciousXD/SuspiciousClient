import Settings from "./config";
import { data, PREFIX } from "./utils/util";
import "./features/chat";
import "./features/display";
const prefix = '&b[Suspicious Client]&r';
const mc = Client.getMinecraft();
const RightClick = new KeyBind(mc.field_71474_y.field_74313_G);
const LeftClick = new KeyBind(mc.field_71474_y.field_74312_F);
const C08PacketPlayerBlockPlacement = Java.type('net.minecraft.network.play.client.C08PacketPlayerBlockPlacement');
const C0APacketAnimation = Java.type('net.minecraft.network.play.client.C0APacketAnimation');
const C09PacketHeldItemChange = Java.type('net.minecraft.network.play.client.C09PacketHeldItemChange');
const BP = Java.type('net.minecraft.util.BlockPos');
register("command", () => Settings.openGUI()).setName("susconfig", true);
register("step", () => {
    if (data.first_time) {
        data.first_time = false;
        data.save();
        ChatLib.chat("");
        new TextComponent(ChatLib.getCenteredText(`${PREFIX}&aDo /susconfig For Settings!`)).chat();
        new TextComponent(ChatLib.getCenteredText(`${PREFIX}&aJoin Our Discord!  &b&nDiscord&r &7(Click)`)).setClickAction("open_url").setClickValue("https://discord.gg/SXktUvnE7T").chat();
        ChatLib.chat("");}
        }).setFps(1);

register("command", () => {
    ChatLib.clearChat();
    ChatLib.chat(prefix + ' Cleared the Chat!')
}).setName("suschat");

register('WorldLoad', () => {
    if (everythingON === true) {
        if (ScoreBoard() === true) {
            onStop()
        }
    }
});
let startMiningAgain = false;
let coolDownScan = 1000;
let coolDownInOut_enterExit = 0;
let coolDownInOut_Confirm = 0;
let coolDownWaitTime = 1000;
register('Tick', () => {
    if (Enabled_findlobby === true) {
        const _0xedbbx99 = Player.getContainer();
        if (_0xedbbx99.getSize() === 90 || _0xedbbx99.getSize() === 63) {
            if (_0xedbbx99.getStackInSlot(16) != null) {
                if (_0xedbbx99.getStackInSlot(16).getID() === 328) {
                    if (coolDownInOut_enterExit < 10) {
                        coolDownInOut_enterExit += 1
                    } else {
                        if (coolDownInOut_enterExit === 10) {
                            _0xedbbx99.click(16, false, 'MIDDLE');
                            coolDownInOut_enterExit = 0
                        }
                    }
                }
            } else {
                if (_0xedbbx99.getStackInSlot(11) != null) {
                    if (_0xedbbx99.getStackInSlot(11).getID() === 159) {
                        if (coolDownInOut_Confirm < 10) {
                            coolDownInOut_Confirm += 1
                        } else {
                            if (coolDownInOut_Confirm === 10) {
                                _0xedbbx99.click(11, false, 'MIDDLE');
                                coolDownInOut_enterExit;
                                coolDownWaitTime = 0
                            }
                        }
                    }
                }
            }
        } else {
            if (coolDownWaitTime < 50) {
                coolDownWaitTime += 1
            } else {
                if (coolDownWaitTime === 50) {
                    coolDownWaitTime += 1;
                    let _0xedbbx9a = World.getTime();
                    let _0xedbbx9b = false;
                    for (let _0xedbbx9c = 0; _0xedbbx9c < list.length; _0xedbbx9c++) {
                        for (let _0xedbbx9d = 0; _0xedbbx9d < locations.length; _0xedbbx9d++) {
                            if (list[_0xedbbx9c].toString().includes(locations[_0xedbbx9d])) {
                                ChatLib.chat(list[_0xedbbx9c]);
                                _0xedbbx9b = true;
                                break
                            }
                        }
                    };
                    if (_0xedbbx9a < 96000 && _0xedbbx9b === true) {
                        onStop_autoFind();
                        ChatLib.chat(prefix + ' Found Good Lobby!');
                    } else {
                        let _0xedbbx9e = Player.getHeldItemIndex();
                        Client.sendPacket(new C09PacketHeldItemChange(8));
                        Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0));
                        Client.sendPacket(new C09PacketHeldItemChange(_0xedbbx9e))
                    }
                }
            }
        }
    }
});
function onStart_autoFind() {
    ChatLib.chat(prefix + ' Auto Lobby Hop On!');
    Enabled_findlobby = true;
    toggleOnOff_findlobby = true;
    let _0xedbbx9e = Player.getHeldItemIndex();
    Client.sendPacket(new C09PacketHeldItemChange(8));
    Client.sendPacket(new C08PacketPlayerBlockPlacement(new BP(-1, -1, -1), 255, Player.getInventory().getStackInSlot(8).getItemStack(), 0, 0, 0));
    Client.sendPacket(new C09PacketHeldItemChange(_0xedbbx9e))
}
function onStop_autoFind() {
    ChatLib.chat(prefix + ' Auto Lobby Hop Off!');
    coolDownWaitTime = 1000;
    Enabled_findlobby = false;
    toggleOnOff_findlobby = false
}
let Enabled_findlobby = false;
let toggleOnOff_findlobby = false;
register('Command', () => {
    if (toggleOnOff_findlobby === false) {
        onStart_autoFind()
    } else {
        if (toggleOnOff_findlobby === true) {
            onStop_autoFind()
        }
    }
}).setName('susch');
let list = Scoreboard.getLines();
let locations = ['Goblin', 'Jungle', 'Mithril', 'Precursor', 'Magma', 'Crystal'];
function ScoreBoard() {
    let _0xedbbx9b = false;
    for (let _0xedbbx9c = 0; _0xedbbx9c < list.length; _0xedbbx9c++) {
        for (let _0xedbbx9d = 0; _0xedbbx9d < locations.length; _0xedbbx9d++) {
            if (list[_0xedbbx9c].toString().includes(locations[_0xedbbx9d])) {
                ChatLib.chat(list[_0xedbbx9c]);
                _0xedbbx9b = true;
                break
            }
        };
        if (_0xedbbx9b === true) {
            break
        }
    };
    if (_0xedbbx9b === true) {
        return false
    } else {
        return true
    }
}


